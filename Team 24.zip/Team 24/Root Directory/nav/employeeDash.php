<div class="nav">
    <ul>
        <li><a href="index.php">Home</a></li>
        <li><a href="employeeDash.php">Pending Orders</a></li>
        <li><a href="employeeReport.php">Report</a></li>
        <li><a href="stock.php">Stock</a></li>
        <li><a href="myAccount.php">My Account</a></li>
        <li><a href="logoff.php">Logout</a></li>
    </ul>
</div>

<script type="text/javascript">
setTimeout(function(){
    location.reload();
},180000); 
//auto-refresh every minute.
</script>